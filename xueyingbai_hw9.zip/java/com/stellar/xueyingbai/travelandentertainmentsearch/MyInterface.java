package com.stellar.xueyingbai.travelandentertainmentsearch;

public interface MyInterface {
    public void show_new_page();
}
